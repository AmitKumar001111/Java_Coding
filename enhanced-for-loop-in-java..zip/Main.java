// enhaced-for loop in java.

class Main {
    public static void main(String[] args){
         int[] numbers = {1,2,3,4,5,6,7,8,9,10}; // Array which has int types elements only , and name of this array is numbers
         for (int item : numbers) // item is a variable here .
         {
             System.out.println("Count is: " + item);
         }
    }
}