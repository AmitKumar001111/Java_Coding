import java.util.Scanner;

class Main {
    public static void main(String[] args){
        // Scanner sc = new Scanner(System.in);
        
        // System.out.print("Enter the Value of count : ");
        // int count = sc.nextInt();
        int count = 1;
        while (count < 11) {
            System.out.println("Count is: " + count);
            count++;
        }
    }
}